package com.cg.project.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Car {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int carCode;
	private String carName;
	@ManyToOne
	private Customer customer;
	public Car() {
		super();
	}
	public Car(int carCode, String carName, Customer customer) {
		super();
		this.carCode = carCode;
		this.carName = carName;
		this.customer = customer;
	}
	public int getCarCode() {
		return carCode;
	}
	public void setCarCode(int carCode) {
		this.carCode = carCode;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Car [carCode=" + carCode + ", carName=" + carName
				+ ", customer=" + customer + "]";
	}
	
}
