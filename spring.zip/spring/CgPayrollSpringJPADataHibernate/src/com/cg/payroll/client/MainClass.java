package com.cg.payroll.client;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
public class MainClass {

	public static void main(String[] args) throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices service = (PayrollServicesImpl) context.getBean("payrollServices");
		int id=service.acceptAssociateDetails(1500, "shravan", "marutha", "production", "Acon", "ewr112", "shravan@gmail.com", 1212,"dsf","dsfd", 20000, 1000,1000);
		service.calculateNetSalary(id);
		System.out.println(service.getAssociateDetails(id));
	}
}