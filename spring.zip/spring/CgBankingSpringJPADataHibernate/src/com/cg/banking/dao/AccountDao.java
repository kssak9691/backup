package com.cg.banking.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.banking.beans.Account;
public interface AccountDao extends JpaRepository<Account, Long>{
	
}
