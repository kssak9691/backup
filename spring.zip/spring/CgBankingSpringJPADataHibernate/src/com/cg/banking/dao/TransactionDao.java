package com.cg.banking.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public interface TransactionDao extends JpaRepository<Transaction, Integer> {

}
