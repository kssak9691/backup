package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class InvalidAccountTypeException extends Exception{
	private  String str;
	public InvalidAccountTypeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountTypeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidAccountTypeException(String message) {
		super(message);
		str = message;
		
	}

	public InvalidAccountTypeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InvalidAccountTypeException [" + str + "]";
	}
	
}
