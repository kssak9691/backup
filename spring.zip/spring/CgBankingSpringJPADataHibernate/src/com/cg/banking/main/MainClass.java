package com.cg.banking.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException,
	AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		ApplicationContext context = new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices service = (BankingServices) context.getBean("bankingServices");
		long accountNo1=service.openAccount("Savings", 1000, 111);
		System.out.println(service.depositAmount(accountNo1, 1000));
		long accountNo2=service.openAccount("Savings", 1000, 222);
		System.out.println(service.depositAmount(accountNo2, 1000));
		System.out.println(service.fundTransfer(accountNo2, accountNo1, 500, 111));
		System.out.println(service.getAccountAllTransaction(accountNo1));
	}
}
