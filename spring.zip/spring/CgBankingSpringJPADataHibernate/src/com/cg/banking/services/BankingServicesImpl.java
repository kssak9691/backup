package com.cg.banking.services;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.dao.AccountDao;
import com.cg.banking.dao.TransactionDao;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	@Autowired
	private AccountDao accountDao;
	@Autowired
	private TransactionDao transactionDao;
	@Override
	public long openAccount(String accountType, float initBalance,int pinNumber)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		Account account = new Account(pinNumber, accountType, "Active", initBalance);
		return accountDao.save(account).getAccountNo();
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException, InvalidAmountException {
		Account account =accountDao.findById(accountNo).get();
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction = new Transaction(amount, "Deposit",account);
		transactionDao.save(transaction);
		account =accountDao.save(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
			Account account =accountDao.findById(accountNo).get();
			if(account==null)
				throw new AccountNotFoundException("Account not found");
			if(account.getPinNumber()==pinNumber){
			account.setAccountBalance(account.getAccountBalance()-amount);
			Transaction transaction = new Transaction(amount, "Withdraw",account);
			account = accountDao.save(account);
			transactionDao.save(transaction);
			return account.getAccountBalance();
			}
			else
				throw new InvalidPinNumberException("Invalid pin");
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account1 =accountDao.findById( accountNoFrom).get();
		Account account2 =accountDao.findById(accountNoTo).get();
		if(account1==null || account2==null)
			throw new AccountNotFoundException("Account not found");
		if(account1.getPinNumber()==pinNumber){
		account1.setAccountBalance(account1.getAccountBalance()-transferAmount);
		Transaction transaction1 = new Transaction(transferAmount, "Funds Transfer",account1);
		accountDao.save(account1);
		transactionDao.save(transaction1);
		account1.setAccountBalance(account2.getAccountBalance()+transferAmount);
		Transaction transaction2= new Transaction(transferAmount, "Funds Transfer",account2);
		accountDao.save(account2);
		transactionDao.save(transaction2);
		return true;
		}
		else
			throw new InvalidPinNumberException("Invalid pin");
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		return accountDao.findById(accountNo).get();
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
	
		return accountDao.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
			Account account = accountDao.findById(accountNo).get();
		return account.getTransaction();
	}



}
