package com.cg.banking.exceptions;

@SuppressWarnings("serial")
public class InvalidPinNumberException extends Exception{
	private  String str;
	public InvalidPinNumberException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidPinNumberException(String message) {
		super(message);
		str = message;
	}

	public InvalidPinNumberException(Throwable cause) {
		super(cause);
	}

	public InvalidPinNumberException() {
		super();
	}

	@Override
	public String toString() {
		return "InvalidPinNumberException [" + str + "]";
	}
	
}
