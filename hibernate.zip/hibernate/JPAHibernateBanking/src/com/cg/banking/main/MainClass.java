package com.cg.banking.main;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException,
	AccountBlockedException {
		BankingServicesImpl service = new BankingServicesImpl();
		long accountNo=service.openAccount("Savings", 5000);
		System.out.println(accountNo);
		System.out.println(service.depositAmount(accountNo, 2000));
		System.out.println(service.depositAmount(accountNo, 2000));
		System.out.println(service.getAccountAllTransaction(accountNo));
	}
}
