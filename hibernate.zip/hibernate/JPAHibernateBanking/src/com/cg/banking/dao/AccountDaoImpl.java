package com.cg.banking.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.util.EntityManagerFactoryProvider;

public class AccountDaoImpl implements AccountDao{
	EntityManagerFactory factory = EntityManagerFactoryProvider.geEntityManagerFactory();
	@Override
	public long save(Account account) {
		EntityManager entityManager =factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return 	account.getAccountNo();
	}

	@Override
	public Account findOne(long accountNo){
		EntityManager entityManager = factory.createEntityManager();
		Account account=entityManager.find(Account.class,accountNo);
		return account;
	}

	@Override
	public ArrayList<Account> findAll() {
		EntityManager entityManager = factory.createEntityManager();
		Query query =entityManager.createNamedQuery("getAllAccount");
		@SuppressWarnings("unchecked")
		ArrayList<Account> list = (ArrayList<Account>) query.getResultList();
		return list;
	}

	@Override
	public Account updateAccount(Account account) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(account);
		entityManager.getTransaction().commit();
		entityManager.close();
		return account;
	}

	
	@Override
	public ArrayList<Transaction> findAllTransactions(long accountNo) {
		EntityManager entityManager = factory.createEntityManager();
		Account account =findOne(accountNo);
		Query query = entityManager.createNamedQuery("getAllAccountTransactions");
		query.setParameter("account", account);
		@SuppressWarnings("unchecked")
		ArrayList<Transaction> list = (ArrayList<Transaction>) query.getResultList();
		return list;
	}

	@Override
	public Transaction updateTransaction(Transaction transaction) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(transaction);
		entityManager.getTransaction().commit();
		entityManager.close();
		return transaction;
	}

	
}
