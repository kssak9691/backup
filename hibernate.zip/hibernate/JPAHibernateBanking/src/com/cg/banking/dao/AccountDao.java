package com.cg.banking.dao;

import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
public interface AccountDao {
	long save(Account account) ;
	Account findOne(long accountNo);
	ArrayList<Account> findAll();
	ArrayList<Transaction> findAllTransactions(long accountNo) ;
	Transaction updateTransaction( Transaction transaction);
	Account updateAccount(Account account);
}
