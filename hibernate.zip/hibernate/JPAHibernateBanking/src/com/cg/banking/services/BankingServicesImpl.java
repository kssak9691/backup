package com.cg.banking.services;
import java.util.List;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.dao.AccountDao;
import com.cg.banking.dao.AccountDaoImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	AccountDao dao =new AccountDaoImpl();
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException,
			BankingServicesDownException {
		Account account = new Account(accountType, "Active", initBalance);
		return dao.save(account);
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException,
			AccountBlockedException, InvalidAmountException {
		Account account =dao.findOne(accountNo);
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction = new Transaction(amount, "Deposit",account);
		dao.updateTransaction(transaction);
		account = dao.updateAccount(account);
		return account.getAccountBalance();
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
			Account account =dao.findOne(accountNo);
			if(account==null)
				throw new AccountNotFoundException("Account not found");
			if(account.getPinNumber()==pinNumber){
			account.setAccountBalance(account.getAccountBalance()-amount);
			Transaction transaction = new Transaction(amount, "Withdraw",account);
			account = dao.updateAccount(account);
			dao.updateTransaction(transaction);
			return account.getAccountBalance();
			}
			else
				throw new InvalidPinNumberException("Invalid pin");
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException {
		Account account1 =dao.findOne(accountNoFrom);
		Account account2 =dao.findOne(accountNoTo);
		if(account1==null || account2==null)
			throw new AccountNotFoundException("Account not found");
		if(account1.getPinNumber()==pinNumber){
		account1.setAccountBalance(account1.getAccountBalance()-transferAmount);
		Transaction transaction1 = new Transaction(transferAmount, "Withdraw",account1);
		dao.updateAccount(account1);
		dao.updateTransaction(transaction1);
		account1.setAccountBalance(account2.getAccountBalance()+transferAmount);
		Transaction transaction2= new Transaction(transferAmount, "Deposit",account2);
		dao.updateAccount(account2);
		dao.updateTransaction(transaction2);
		return true;
		}
		else
			throw new InvalidPinNumberException("Invalid pin");
	}

	@Override
	public Account getAccountDetails(long accountNo)
			throws AccountNotFoundException, BankingServicesDownException {
		return dao.findOne(accountNo);
	}

	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
	
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		
		return dao.findAllTransactions(accountNo);
	}



}
