package com.cg.payroll.dao;
import java.util.ArrayList;

import com.cg.payroll.beans.*;
import com.cg.payroll.util.EntityManagerFactoryProvider;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
public class AssociateDAOImpl implements AssociateDAO  {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
	@Override
	public Associate save(Associate associate) {
		EntityManager entityManager =factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate;
	}

	@Override
	public Associate findOne(int associateId) {
		EntityManager entityManager = factory.createEntityManager();
		return entityManager.find(Associate.class,associateId);
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public ArrayList<Associate> findAll() {
		EntityManager entityManager = factory.createEntityManager();
		Query query =entityManager.createQuery("from Associate a");
		ArrayList<Associate> list = (ArrayList<Associate>) query.getResultList();
		return list;
	}

	@Override
	public boolean update(Associate associate) {
		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	
}
