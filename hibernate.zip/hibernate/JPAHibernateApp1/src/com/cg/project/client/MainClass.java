package com.cg.project.client;
import com.cg.project.beans.Associate;
import com.cg.project.beans.BankDetails;
import com.cg.project.beans.Salary;
import com.cg.project.daoservices.AssociateDAO;
import com.cg.project.daoservices.AssociateDAOImpl;

public class MainClass {

	public static void main(String[] args) {
		AssociateDAO dao = new AssociateDAOImpl();
	/*	Associate associate = new Associate("Shravan","Marutha","Sr.Con", "shravan@gmail.com");
		associate =dao.save(associate);
		int associateId = associate.getAssociateId();
		System.out.println(associateId);
		System.out.println(dao.findAll());
		*/
		Associate associate = new Associate(25000, "Shravan", "Marutha", "Production", "A.Con", "EXPHM324Q", "shravan@gmail.com", new BankDetails(1121015, "Hdfc", "Hdfc00204"),new Salary( 20000, 1500, 1500));
		associate =dao.save(associate);
		int associateId = associate.getAssociateId();
		System.out.println(associateId);
		System.out.println(dao.findFewAssociates(30000));
	}

}
