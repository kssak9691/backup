package com.cg.payroll.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

/**
 * Servlet implementation class GetAssoicateDetailsServlet
 */
@WebServlet("/GetAssoicateDetailsServlet")
public class GetAssoicateDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAssoicateDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PayrollServices service = new PayrollServicesImpl();
		int associateId = Integer.parseInt(request.getParameter("associateId"));
		try {
			Associate associate=service.getAssociateDetails(associateId);
			request.setAttribute("associate", associate);
			RequestDispatcher dispatcher=request.getRequestDispatcher("displayAssociateDetails.jsp");
			dispatcher.forward(request, response);
		} catch (AssociateDetailsNotFoundException
				| PayrollServicesDownException e) {
			String error = e.getMessage();
			request.setAttribute("error", error);
			RequestDispatcher dispatcher=request.getRequestDispatcher("errorAssociateDetails.jsp");
			dispatcher.forward(request, response);
		}
		
	}

}
