alter table Customer
modify Cust_Name varchar2(30) not null;
alter table Customer
Rename column Cust_Name to CustomerName;
