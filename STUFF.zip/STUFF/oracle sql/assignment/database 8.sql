alter table cust_Table
enable constraint custid_prim;