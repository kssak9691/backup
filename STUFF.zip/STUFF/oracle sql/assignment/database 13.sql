create table suppliers(
	SuppId number(5),
	SName varchar(20),
	Addr1 varchar(30),
	Addr2 varchar(30),
	Contactno number(10));
