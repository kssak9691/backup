alter table cust_table
add constraint Custid_Prim primary key (customerId);