alter table cust_Table
drop constraint custid_prim;