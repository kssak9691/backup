create table Customer(
CustomerId	Number(5),
Cust_Name	varchar2(20),
Address1	Varchar2(30),
Address2 	Varchar2(30)
);