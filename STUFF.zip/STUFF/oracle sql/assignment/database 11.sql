alter table cust_table
 add E_mail varchar(20);