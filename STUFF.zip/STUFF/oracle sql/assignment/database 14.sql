drop table Suppliers;
create table CustomerMaster(
	CustomerId	Number(5),
    CustomerName Varchar2(30) Not Null,
	Addressl Varchar2(30) Not Null,
	Address2 Varchar2(30),
	Gender	Varchar2(1),
	Age	Number(3),
	PhoneNo	Number(10),
	constraint CustId_PK primary key(customerid)
) ;