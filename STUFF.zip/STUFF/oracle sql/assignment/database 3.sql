alter table customer
add Gender Varchar2(1);
alter table customer
add  Age Number(3);
alter table customer
add PhoneNo Number(10);
alter table Customer
rename to cust_table;