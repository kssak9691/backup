create table Employee_Master
         (employeeId number(10)not null,
          FirstName varchar2(50)not null,
          LastName varchar2(50)not null);