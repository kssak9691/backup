insert into Employee_Master
      values(11143,'Shravan','Marutha',9550537838,'shravan@gmail.com','sr.con');
insert into Employee_Master
      values(11254,'Ravan','Marutha',9550523838,'ravan@gmail.com','sr.con');
insert into Employee_Master
      values(11354,'satish','rao',9866293212,'satish@gmail.com','sr.con');
insert into Employee_Master
      values(11421,'Kaushal','Army',9503434543,'kaushal@gmail.com','con');
insert into Employee_Master
      values(11543,'Geetha','Babu',9582547634,'geetha@gmail.com','sr.con');
insert into Employee_Master
      values(11634,'Tanish','Zeus',9450537323,'tanish@gmail.com','sr.con');
insert into Employee_Master
      values(11732,'Sunaina','Dazzle',7450343423,'suniana@gmail.com','con');
insert into Employee_Master
      values(11821,'Samrat','Ember',8754437323,'samrat@gmail.com','sr.con');
insert into Employee_Master
      values(1191,'nuthan','Ursa',7850537323,'nuthan@gmail.com','sr.con');
insert into Employee_Master
      values(12021,'rollrider','Alchemist',8350537323,'rollrider@gmail.com','sr.con');
insert into Employee_Master
      values(1213,'Ganesh','Spectre',7450532723,'ganesh@gmail.com','con');
insert into Employee_Master
      values(12232,'bhanu','Voker',9400037320,'bhanu@gmail.com','sr.Manager');
insert into Employee_Master
      values(12321,'Teja','Phantom',9450787823,'Teja@gmail.com','sr.con');
insert into Employee_Master
      values(11612,'Deepthi','Lina',9079853733,'deepthi@gmail.com','sr.con');
insert into Employee_Master
      values(11699,'Ramesh','Magnus',9479090823,'ramesh@gmail.com','sr.con');