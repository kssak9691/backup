var var1="Hello World"

function doSomeWork(){
	var var1="Inside function ";
	document.write("<br>Value of var1 "+var1);
}

document.write("<br>Value of var1 "+var1);
doSomeWork();
document.write("<br>Value of var1 "+var1);