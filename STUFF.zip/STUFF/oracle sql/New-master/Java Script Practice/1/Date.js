var date=new Date();

document.write(date.getDay()+" "+date.getMonth()+" "+date.getFullYear());

document.write("<br>"+date);