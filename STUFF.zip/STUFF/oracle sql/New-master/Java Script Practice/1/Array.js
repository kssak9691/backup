var strList= ["Kaushal","Tanish","Samrat","Roll Rida","Geetha","Deepthi"];

var strList= new Array("Kaushal","Tanish","Samrat","Roll Rida","Geetha","Deepthi");

document.write(strList);

strList.sort();

document.write("<br>"+strList);

strList.pop();

document.write("<br>"+strList);

strList.push("Nutan Naidu");

document.write("<br>"+strList);




"Kaushal Army".charAt(5)

"Kaushal Army".concat(" Abhinav Avengers")

"Abhinav".match("Abhi")

