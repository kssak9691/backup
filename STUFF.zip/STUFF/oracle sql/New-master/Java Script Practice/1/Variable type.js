var var1="Hello World"
if(isNaN(var1)){
	document.write("Not a number");
}
else{
	document.write("It's a Number");
}

var var1=10;
var var2=false;

var var3="Hello World";
var var4;

document.write("<br>"+typeof(var1));
document.write("<br>"+typeof(var2));
document.write("<br>"+typeof(var3));
document.write("<br>"+typeof(var4));