document.write("Kaushal Army".charAt(5))

document.write("Kaushal Army".concat(" Abhinav Avengers"))

document.write("Abhinav".match("Abhi"))

document.write("Kaushal Army".replace("Army","Manda"))

document.write("Abhinav Explores".substr(,8))

document.write("ABHI".toLowerCase())

document.write("omni".toUpperCase())

document.write("Samabhi".bold())

document.write("Samabhi".italics())

document.write("Samabhi".fontcolor("#0000FF"))

document.write("Samabhi".fontsize("5"))

document.write("Samabhi".big())

document.write("Samabhi".small())