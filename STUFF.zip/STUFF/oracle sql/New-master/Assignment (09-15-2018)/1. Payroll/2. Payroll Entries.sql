insert into Associate
	values('A101',2000,'Abhi','Kaush','ECE','Con','ADGFD0213L','ak101@gmail.com');
insert into Associate
	values('B101',2000,'Sesh','Sai','CSE','Sr.Con','SGHAS1356P','ss102@gmail.com');
insert into Associate
	values('C101',2000,'Raghav','Venkat','EEE','Asst.Con','LKAHG0251I','rv103@gmail.com');
insert into Associate
	values('D101',2000,'Sam','Laksh','PIE','Manager','YHGUI4523K','sl104@gmail.com');
insert into Associate
	values('E101',2000,'Krish','Ram','MME','Asst.Manager','RTYWF0154D','kr105@gmail.com');
insert into Associate
	values('F101',2000,'Sraavs','Maddy','EIE','Sr.Manager','OPDFS4502G','sm106@gmail.com');
insert into Associate
	values('G101',2000,'Hari','Priya','FAB','Clerk','AFHGY0164T','hp107@gmail.com');
insert into Associate
	values('H101',2000,'Goku','Kakarrot','CIVIL','Dean','RTAOS0780B','gk108@gmail.com');
insert into Associate
	values('I101',2000,'Vegeta','Saiyan','ME','Asst.Dean','PHIOS4589A','vs109@gmail.com');
insert into Associate
	values('I101',2000,'Ash','Ketchum','FD','P.Master','SCFDR0549P','ak110@gmail.com');
	
	
	
insert into BankDetails
	values(1478562315,'HDFC','HDFC123054');
insert into BankDetails
	values(1265304875,'SBI','SBIN123054');
insert into BankDetails
	values(4523467915,'ICICI','ICIC123054');
insert into BankDetails
	values(1546325492,'PNB','PNBN123054');
insert into BankDetails
	values(4563128974,'IHB','IHBN123054');
insert into BankDetails
	values(4632152648,'VCV','VCVN123054');
insert into BankDetails
	values(1456328974,'HSBC','HSBC123054');
insert into BankDetails
	values(1265506875,'HDFC','HDFC123054');
insert into BankDetails
	values(1265634875,'SBI','SBIN123054');
insert into BankDetails
	values(1267890275,'SBI','SBIN123054');
	
	
	
insert into Salary
	values(153514,56146,35165,3514,313,31352,351,315,315,315,31353);
insert into Salary
	values(6516351,3131,3513,3151,51135,1355,1135,1335,1362,56126,1651653);
insert into Salary
	values(3542441,3513,351,3135,3513,351,848,6854,6513,3513,35146555);
insert into Salary
	values(153514,56146,35165,3514,313,31352,351,315,315,315,31353);
insert into Salary
	values(6516351,3131,3513,3151,51135,1355,1135,1335,1362,56126,1651653);
insert into Salary
	values(3542441,3513,351,3135,3513,351,848,6854,6513,3513,35146555);
insert into Salary
	values(153514,56146,35165,3514,313,31352,351,315,315,315,31353);
insert into Salary
	values(6516351,3131,3513,3151,51135,1355,1135,1335,1362,56126,1651653);
insert into Salary
	values(3542441,3513,351,3135,3513,351,848,6854,6513,3513,35146555);
insert into Salary
	values(3542441,3513,351,3135,3513,351,848,6854,6513,3513,35146555);
