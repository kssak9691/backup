insert into Transaction
                   values(001,'1358505',123456,'NEFT','PUNE','UPI','PENDING');
insert into Transaction
                   values(002,'125345',14566,'RTGS','RAJAHMUNDRY','WITHDRAWAL','SUCCESS');
insert into Transaction
                   values(003,'23256605',546,'IMPS','JAMSHEDPUR','Deposit','Unsuccessful');
insert into Transaction
                   values(004,'58623698',1245,'NEFT','SUSSEX','TRANSFER','Cancelled');
insert into Transaction
                   values(005,'13874565',1526,'RTGS','PYONGYANG','ONLINE','PENDING');
insert into Transaction
                   values(006,'25142896',1274,'IMPS','SEOUL','UPI','CANCELLED');
insert into Transaction
                   values(007,'12581997',2345,'NEFT','TEXAS','ONLINE','SUCCESS');
insert into Transaction
                   values(008,'05012563',258,'IMPS','PARIS','WITHDRAWAL','UNSUCCESSFUL');
insert into Transaction
                   values(009,'25121886',125878,'RTGS','ALASKA','DEPOSIT','PENDING');
insert into Transaction
                   values(010,'13035698',17458,'IMPS','SAGUTURU','TRANSFER','CANCELLED');
















