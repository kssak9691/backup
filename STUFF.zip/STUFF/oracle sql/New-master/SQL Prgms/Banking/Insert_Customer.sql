insert into Customer
                   values(001,'Kaushal','Army','123456','2K_walk@bigboss.com',123987,'Cd45678','13031997');
insert into Customer
                   values(002,'Sanjana','Anne','122556','1stweek@bigboss.com',145387,'Cd487578','1358697');
insert into Customer
                   values(003,'Nutan','Naidu','1586256','2ndweek@bigboss.com',789567,'bg562578','1583697');
insert into Customer
                   values(004,'Kireeti','Dharmaraj','125664','3rdweek@bigboss.com',85687,'hg25645','853599');
insert into Customer
                   values(005,'Tanish','Tuskers','987456','130K@bigboss.com',546327,'SY15678','1385267');
insert into Customer
                   values(006,'Deepti','Banana','584656','tanish@bigboss.com',256317,'Th857478','1300297');
insert into Customer
                   values(007,'Samrat','Reddy','587156','tejaswi@bigboss.com',574178,'TJ58278','13751997');
insert into Customer
                   values(008,'Deepthi','Nallamothu','125356','bza@bigboss.com',17527,'BZA25678','135847');
insert into Customer
                   values(009,'Roll','Rida','185689','galli@bigboss.com',124527,'GLP45278','18954297');
insert into Customer
                   values(010,'Amit','Tiwary','123456','nonsense@bigboss.com',12287,'C68578','1301235');




