insert into Address
                   values('Rajahmundry','AP',533101,'India');
insert into Address
                   values('Pune','Maharastra',733101,'India');
insert into Address
                   values('South Carolina','Texas',95101,'USA');
insert into Address
                   values('Sussex','Windsor',2101,'England');
insert into Address
                   values('Seoul','Wogram',8501,'South korea');
insert into Address
                   values('Pyongyang','Ho Ji Ming',53251,'North Korea');
insert into Address
                   values('Jin u Lin','Nyuchitang',2501,'Vietnam');
insert into Address
                   values('Edinburgh','Bairstock',55601,'Scotland');
insert into Address
                   values('Jamshedpur','Jharkhand',831014,'India');
insert into Address
                   values('Karimnagar','Telangana',530581,'India');







































