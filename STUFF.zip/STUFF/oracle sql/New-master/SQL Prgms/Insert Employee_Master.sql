insert into Employee_Master
	values(101,'Abhi','Kaush','Con','ak101@gmail.com','101101');
insert into Employee_Master
	values(102,'Sesh','Sai','Sr.Con','ss102@gmail.com','102102');
insert into Employee_Master
	values(103,'Raghav','Venkat','Asst.Con','rv103@gmail.com','103103');
insert into Employee_Master
	values(104,'Sam','Laksh','Manager','sl104@gmail.com','104104');
insert into Employee_Master
	values(105,'Krish','Ram','Asst.Manager','kr105@gmail.com','105105');
insert into Employee_Master
	values(106,'Sraavs','Maddy','Sr.Manager','sm106@gmail.com','106106');
insert into Employee_Master
	values(107,'Hari','Priya','Clerk','hp107@gmail.com','107107');
insert into Employee_Master
	values(108,'Goku','Kakarrot','Dean','gk108@gmail.com','108108');
insert into Employee_Master
	values(109,'Vegeta','Saiyan','Asst.Dean','vs109@gmail.com','109109');
insert into Employee_Master
	values(110,'Ash','Ketchum','P.Master','ak110@gmail.com','110110');
insert into Employee_Master
	values(111,'Van','Helsing','V.Manager','vh111@gmail.com','111111');
insert into Employee_Master
	values(112,'Sam','Abhi','Con','sa112@gmail.com','112112');
insert into Employee_Master
	values(113,'Barry','Allen','Asst.Con','ba113@gmail.com','113113');
insert into Employee_Master
	values(114,'Olliver','Queen','Sr.Manager','oq114@gmail.com','114114');
insert into Employee_Master
	values(115,'Kara','Danvers','Manager','kd115@gmail.com','115115');