alter table Employee_Master
add constraint pk_empid PRIMARY KEY(EmployeeId);