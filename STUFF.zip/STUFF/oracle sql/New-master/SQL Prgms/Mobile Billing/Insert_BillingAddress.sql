insert into BillingAddress
                   values('Rajahmundry','AP',533101,'India');
insert into BillingAddress
                   values('Pune','Maharastra',733101,'India');
insert into BillingAddress
                   values('South Carolina','Texas',95101,'USA');
insert into BillingAddress
                   values('Sussex','Windsor',2101,'England');
insert into BillingAddress
                   values('Seoul','Wogram',8501,'South korea');
insert into BillingAddress
                   values('Pyongyang','Ho Ji Ming',53251,'North Korea');
insert into BillingAddress
                   values('Jin u Lin','Nyuchitang',2501,'Vietnam');
insert into BillingAddress
                   values('Edinburgh','Bairstock',55601,'Scotland');
insert into BillingAddress
                   values('Jamshedpur','Jharkhand',831014,'India');
insert into BillingAddress
                   values('Karimnagar','Telangana',530581,'India');







































