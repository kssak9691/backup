insert into Plan
                            values(001,100,10,10,20,20,150,'1.2pPERsec','1.5pPERsec','1.8pPERmsg','1.0pPERmsg','1.2pPERmb');
insert into Plan
                            values(002,200,20,20,30,30,250,'2.2pPERsec','2.5pPERsec','2.8pPERmsg','2.0pPERmsg','2.2pPERmb');
insert into Plan
                            values(003,300,30,30,40,40,350,'3.2pPERsec','3.5pPERsec','3.8pPERmsg','3.0pPERmsg','3.2pPERmb');
insert into Plan
                            values(004,400,40,40,50,50,450,'4.2pPERsec','4.5pPERsec','4.8pPERmsg','4.0pPERmsg','4.2pPERmb');
insert into Plan
                            values(005,500,50,50,60,60,550,'5.2pPERsec','5.5pPERsec','5.8pPERmsg','5.0pPERmsg','5.2pPERmb');
insert into Plan
                            values(006,600,60,60,70,70,650,'6.2pPERsec','6.5pPERsec','6.8pPERmsg','6.0pPERmsg','6.2pPERmb');
insert into Plan
                            values(007,700,70,70,80,80,750,'7.2pPERsec','7.5pPERsec','7.8pPERmsg','7.0pPERmsg','7.2pPERmb');
insert into Plan
                            values(008,800,80,80,90,90,850,'8.2pPERsec','8.5pPERsec','8.8pPERmsg','8.0pPERmsg','8.2pPERmb');
insert into Plan
                            values(009,900,90,90,100,100,950,'9.2pPERsec','9.5pPERsec','9.8pPERmsg','9.0pPERmsg','9.2pPERmb');
insert into Plan
                            values(010,1000,100,100,200,200,1050,'10.2pPERsec','10.5pPERsec','10.8pPERmsg','10.0pPERmsg','10.2pPERmb');
