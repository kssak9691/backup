alter table Employee_Master
add designation varchar2(50)
add emailID varchar2(50)
add mobileNo varchar(15);