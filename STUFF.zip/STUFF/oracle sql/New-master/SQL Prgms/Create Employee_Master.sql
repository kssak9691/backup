create table Employee_Master
		(employeeId number(10) NOT NULL,
		FirstName varchar2(50) NOT NULL,
		LastName varchar(50) not null);


