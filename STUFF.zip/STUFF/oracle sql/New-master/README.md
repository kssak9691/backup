All check source -----------CG Trng--------------
