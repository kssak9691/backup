DECLARE
	empRecord	emp%ROWTYPE;
BEGIN
	SELECT * INTO empRecord from emp
		where empno=7369;
	DBMS_OUTPUT.PUT_LINE(empRecord.empno||' '||empRecord.ename);
EXCEPTION
	WHEN NO_DATA_FOUND
	THEN DBMS_OUTPUT.PUT_LINE('NO SUCH DATA');
end;	