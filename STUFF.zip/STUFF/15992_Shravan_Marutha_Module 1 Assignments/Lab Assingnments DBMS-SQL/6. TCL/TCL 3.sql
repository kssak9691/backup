insert into Customer
values(6003,'John','#11a Chicago','#114 Chicago','M',45,439525,19000,60);
