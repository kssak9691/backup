insert into Customer
values(&customerId,&cust_name,&address1,&address2,&gender,
&age,&phoneNo,&ledgerBalance);