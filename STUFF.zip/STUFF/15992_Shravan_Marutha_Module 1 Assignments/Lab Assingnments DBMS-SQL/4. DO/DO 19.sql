Alter table AccountsMaster
Add constraint Balance_Check check (LedgerBalance>5000);