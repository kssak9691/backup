INSERT INTO CustomerMaster
	values(1000,'Allen','#115Chicago','#115Chicago','M',25,7878776);
INSERT INTO CustomerMaster
	values(1001,'George','#116France','#116France','M',25,434524);
INSERT INTO CustomerMaster	
	values(1002,'Becker','#114New York','#114New york','M',45,431525);