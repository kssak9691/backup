ALTER TABLE Cust_Table
ADD E_mail varchar2(30);