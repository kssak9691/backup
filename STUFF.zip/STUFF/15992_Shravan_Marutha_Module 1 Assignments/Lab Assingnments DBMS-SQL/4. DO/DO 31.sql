create index idx_emp_hiredate
on employee(hiredate);