create index no_name on cust_table(customerid);
select * from cust_table;