insert into department_master values(seq_dept.nextval,'Electronics');
insert into department_master values(seq_dept.nextval,'marketing');
insert into department_master values(seq_dept.nextval,'computers');
