ALTER TABLE Cust_Table
DISABLE  CONSTRAINT CustId_Prim;

INSERT INTO Cust_Table values(1002,'Becker','#114 New York','#114 New York','M',45,431525);
INSERT INTO Cust_Table values(1003,'Nanapatekar','#115 India','#115 India','M',45,431525);