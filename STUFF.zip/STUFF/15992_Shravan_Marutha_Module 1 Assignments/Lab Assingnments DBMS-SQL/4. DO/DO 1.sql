create table Customer
(CustomerId number(5),
Cust_Name varchar2(20),
Address1 varchar2(30),
Address2 varchar2(30));
