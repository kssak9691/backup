CREATE SEQUENCE seq_dept
start with 40
increment by 10 
minvalue 0
maxvalue 200
cycle;