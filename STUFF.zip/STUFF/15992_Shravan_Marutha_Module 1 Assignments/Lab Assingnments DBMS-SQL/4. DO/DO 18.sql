Alter table AccountsMaster
Add constraint checkk_ac check (Accounttype ='NRI' or Accounttype='IND');