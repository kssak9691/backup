INSERT INTO Cust_Table
	VALUES(1002,'john','#114Chicago','#114Chicago','M',45,439525);