delete from employee
  where dept_name="SALES";