insert into Employee
 values(7369,'SMITH',null,null,null,800,null ,20);
 insert into Employee
 values(7499,'ALLEN',null,null,null ,1600, null,30);
 insert into Employee
 values(7521,'WARD',null,null ,null ,1250,null ,30);
 insert into Employee
 values(7566,'JONES',null,null ,null ,2975,null ,20);
 insert into Employee
 values(7654,'MARTIN',null, null, null,1250,null ,30);
 insert into Employee
 values(7698,'BLAKE',null,null , null,2850, null,30);
 insert into Employee
 values(7369,'CLARK',null, null,null ,2450,null ,10);
 insert into Employee
 values(7369,'SCOTT',null,null ,null ,3000, null,20);
 insert into Employee
 values(7839,'KING',null, null,null ,5000,null ,10);
 insert into Employee
 values(7844,'TURNER',null, null,null ,1500,null ,30);
 insert into Employee
 values(7876,'ADAMS',null, null, null,1100, null,20);
 insert into Employee
 values(7900,'JAMES',null, null, null,950,null ,30);
 insert into Employee
 values(7902,'FORD',null, null,null ,3000,null ,20);
 insert into Employee
 values(7934,'MILLER',null, null,null ,1300, null,10);