insert into Employee
values(&empno,&ename,&job,&mgr,&hiredate,&sal,&comm,&deptno);