select * from Staff_Master
                              WHERE Mgr_code = NULL;