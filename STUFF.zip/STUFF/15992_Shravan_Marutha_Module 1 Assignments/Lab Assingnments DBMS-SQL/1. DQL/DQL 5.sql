SELECT Staff_Name from Staff_Master
    		WHERE Staff_name LIKE '%\_\%';