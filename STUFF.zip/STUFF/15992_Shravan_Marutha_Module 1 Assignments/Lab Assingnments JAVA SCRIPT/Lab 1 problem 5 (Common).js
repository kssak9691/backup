var msg;
var num;
msg = "<p><code>The actual script is in external script file called Lab 1 Problem 5 (Common).js</code></p>";

function addNos(headVar,bodyVar)
{
	document.write(msg);
	num=headVar+bodyVar;
	return "<b>The sum of the variables </b><I>headVar</I><b> and </b><I>bodyVar</I><b> is </b>"+num;
}	