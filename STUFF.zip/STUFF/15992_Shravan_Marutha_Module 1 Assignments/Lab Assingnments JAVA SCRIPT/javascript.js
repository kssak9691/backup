function compute()
{
var a=document.getElementById('loan').value;
var b=document.getElementById('rate').value;
var c=document.getElementById('period').value;

if(c<7 || c>15)
{
document.getElementById("error").innerHTML="period should be between 7 and 15";

}
else if(a>15)
{
document.getElementById("error1").innerHTML="amount should not be greater than 15 lakhs";
}
else if((c>=7 && c<=15) &&(a<=15))
{
var totinter=(a*b*c)/100;
document.getElementById("totalinterestpay").value=totinter;
var totpay=parseFloat(a)+parseFloat(totinter);
document.getElementById("totalpay").value=totpay;
var payment=(totpay/12)/c;
document.getElementById("pay").value=payment;
}
else{
return false;
}
}