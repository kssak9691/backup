var i=0;
do
{
	if(i%10==0)
	{
		document.write("<br>");
	}
	document.write(i);
	document.write("&nbsp");
	i++;
}
while(i<100);