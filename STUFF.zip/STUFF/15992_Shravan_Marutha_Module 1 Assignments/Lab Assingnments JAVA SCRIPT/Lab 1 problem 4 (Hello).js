function dispHello()
{
	return "<code>This text is displayed by Calling external function </code><b>: Hello World</b>";
}	