var p=1000,n=1,r=10;

var k = 1+(r/100);

var c = 1;
for(var i=1;i<=n;i++)
{
	c = c*k;
}

var g = p*c;

var t = g-p;
document.write("<p>Comp Interest&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;-&ensp;&ensp;&ensp;&ensp;100</p>");