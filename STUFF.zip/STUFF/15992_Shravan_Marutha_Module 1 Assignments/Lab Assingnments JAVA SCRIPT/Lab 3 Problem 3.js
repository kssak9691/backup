var num1 = "University at Capgemini".match('Capgemini');

var num2 = "University at Capgemini".substr(3,6);


document.write("<br><br>Result of str.match('Capgemini')&emsp;&emsp;&nbsp;&nbsp;&emsp;:&emsp;&emsp;"+num1);

document.write("<br><br>Result of str.substr(3,6)&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;:&emsp;&emsp;"+num2);

document.write("<br><br>Hello Javascripters!".toLowerCase());

document.write("<br><br>Hello Javascripters!".toUpperCase());
 