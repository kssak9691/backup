var num = "Capgemini".indexOf("p");

document.write("The character is found at the index&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;-&emsp;&emsp;"+num); 