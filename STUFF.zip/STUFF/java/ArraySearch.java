class ArraySearch{
	public static void main(String[] str){
		int arrList[]={1,2,3,4,5,6};
		int flag=0;
		for(int i=0;i<6;i++){
			if(arrList[i]==10){
				System.out.println("The number is available");
				flag=1;
				break;
			}
		}
		if(flag==0)
			System.out.println("The number is not available");
	}
}