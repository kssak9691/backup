package com.cg.payroll.servlets;

import java.io.IOException;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

/**
 * Servlet implementation class AssociateDetailsServlet
 */
@WebServlet("/AssociateDetailsServlet")
public class AssociateDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AssociateDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PayrollServices service = new PayrollServicesImpl();
		String firstName= request.getParameter("firstName");
		String lastName= request.getParameter("lastName");
		String department= request.getParameter("department");
		String designation= request.getParameter("designation");
		String pancard= request.getParameter("pancard");
		String emailId= request.getParameter("emailId");
		int yearlyInvestmentUnder80c=Integer.parseInt( request.getParameter("yearlyInvestmentUnder80c"));
		int accountNumber= Integer.parseInt(request.getParameter("accountNumber"));
		String bankName= request.getParameter("bankName");
		String ifscCode= request.getParameter("ifscCode");
		int basicSalary=Integer.parseInt( request.getParameter("basicSalary"));
		int epf=Integer.parseInt( request.getParameter("epf"));
		int companyPf=Integer.parseInt( request.getParameter("companyPf"));
		try {
			int associateId=service.acceptAssociateDetails(yearlyInvestmentUnder80c, firstName, lastName, department, designation, pancard, emailId, accountNumber, bankName, ifscCode, basicSalary, epf, companyPf);
			request.setAttribute("associateId",associateId);
			RequestDispatcher dispatcher=request.getRequestDispatcher("displayAssociateId.jsp");
			dispatcher.forward(request, response);
		} catch (PayrollServicesDownException e) {
			e.printStackTrace();
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}

	}
	}


