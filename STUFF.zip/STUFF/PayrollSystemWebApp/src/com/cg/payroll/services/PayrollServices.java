package com.cg.payroll.services;
import java.util.ArrayList;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.*;
public interface PayrollServices {
	int acceptAssociateDetails(int yearlyInvestmentUnder80c, 
			String firstName, String lastName,
			String department, String designation, String pancard,
			String emailId, int accountNumber, String bankName,
			String ifscCode, int basicSalary, int epf, int companyPf) throws PayrollServicesDownException, AssociateDetailsNotFoundException;

	int calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException , PayrollServicesDownException;

	ArrayList<Associate> getAllAsociateDetails() throws PayrollServicesDownException;

}