package com.cg.project.strings;

public class AlphabeticalOrderUpperCase {

	public static void main(String[] args) {
		

	}

}
