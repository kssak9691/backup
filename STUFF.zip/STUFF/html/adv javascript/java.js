<html>
<script>
var employee={};
console.log(employee);
employee.empId=1001;
console.lof(employee.empId);
</script>
</html>