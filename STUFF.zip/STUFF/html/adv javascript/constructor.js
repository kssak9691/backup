function Employee(firstName, lastName,basicSalary){
this.firstName=firstName;
this.lastName=lastName;
this.basicSalary=basicSalary;
this.hra=0;
this.da=0;
this.ta=0;
this.totalSalary=0;
	this.calculateTotalSalary=()=>{
		this.hra=this.basicSalary*10/100;
		this.da=this.basicSalary*8/100;
		this.ta=this.basicSalary*7/100;
		this.totalSalary=this.hra+this.ta+this.da;
		return this.totalSalary;
		}
}

Employee.prototype.email="default@gmail.com"
Employee.prototype.fullName=function(){
	return this.firstName+" "+this.lastName
}
/*
var employee1 = new Employee("shravan","marutha",15000)
employee1.email="shravan@gmail.com"
console.log(employee1.email)
console.log(employee1.fullName()+" "+employee1.calculateTotalSalary())
console.log(employee1.fullName()+" "+employee1.totalSalary)
*/

function PEmployee(firstName,lastName,basicSalary){
	this.hra=0;
	this.da=0;
	this.ta=0;
	Employee.call(this,firstName,lastName,basicSalary)
	this.calculateTotalSalary=()=>{
		this.hra=this.basicSalary*10/100;
		this.da=this.basicSalary*8/100;
		this.ta=this.basicSalary*7/100;
		this.totalSalary=this.hra+this.ta+this.da;
		return this.totalSalary;
		}
}

var pemp= new PEmployee("shravan","marutha",15000)
PEmployee.prototype.email="default@gmail.com"
PEmployee.prototype.fullName=function(){
	return this.firstName+" "+this.lastName
}

console.log(pemp.fullName())