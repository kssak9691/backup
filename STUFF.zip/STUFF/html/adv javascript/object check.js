<html>
<script>
	var myEmployee={
	empId:1001,
	empName:"shravan",
	empDep:"Java",
	isAdmi:false,
	empSalary:5555,
	address:{
		street:"h1 road",
		city:"pune",
		pincode:6321,
		}
	};
	console.log(myEmployee["empId"]);
	console.log(myEmployee.address);
	console.log(myEmployee["address"]["city"]);
	//delete myEmployee.empDep;
	for(code in myEmployee){
	console.log(code);
	console.log(myEmployee[code]);
	}
</script></html>