function Employee(name){
	this.name=name;
}

Employee.prototype.getName= function(){return this.name}

function Department(manager){
	this.manager=manager;
}

Department.prototype.getManagerName=function(){ return this.manager}

Department.prototype = new Employee("CDE")
var dep=new Department()
console.log(dep.getName());