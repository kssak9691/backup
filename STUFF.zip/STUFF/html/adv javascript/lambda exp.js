function addNumbers(num1,num2){
				return num1+num2
			}
			console.log(addNumbers(200,300))			//Arrow Function (Lambda Expression)
			
			var callInterest11=function(baseAmt,interestRate){
				return (baseAmt*interestRate)/100
			}
			console.log(callInterest11(15000,15))