var data= '{"name":"shravan", "age":31}';
var dataparsed= JSON.parse(data);
console.log(dataparsed.name);
console.log(dataparsed.age);

var data='{"name":"ravan","age":30,"address":{"streetAddress":"h1 road","city":"pune"},"phoneNumber":[{"type":"home","number":"1111"},{"type":"office","number":"2222"}]}';
	var json = JSON.parse(data)
	
	console.log(json["name"]);
	console.log(json.name);
	
	console.log(json.address.streetAddress);
	console.log(json["address"].city)
	console.log(json.phoneNumber[0].number);
	console.log(json.phoneNumber[1].type);
	console.log(json.phoneNumber.number);
	
	
function Employee(name, age, salary){
	this.name=name;
	this.age=age;
	this.salary= salary;
}

var employeeObject = new Employee("wew",25,1123);

console.log(employeeObject);
JSON.stringify(employeeObject);
console.log(employeeObject)