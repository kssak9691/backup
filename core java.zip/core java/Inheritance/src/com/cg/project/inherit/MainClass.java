package com.cg.project.inherit;
public class MainClass {

	public static void main(String[] args) {
		/*
		PEmployee pemployee = new PEmployee(101,10000,"Shravan","Marutha");
		pemployee.calculateTotalSalary();
		System.out.println(pemployee.getTotalSalary());
		*/
		Employee emp = new PEmployee(102,10000,"kasuhal","Abhinav");
		PEmployee pemp = (PEmployee)emp;
		emp.calculateTotalSalary();
		System.out.println(pemp.getHra());
		
	}

}
