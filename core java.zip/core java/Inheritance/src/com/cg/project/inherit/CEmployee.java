package com.cg.project.inherit;
public class CEmployee  extends Employee{
	private int totalHrs,variablePay;

	public CEmployee() {
		super();
	}

	public CEmployee(int employeeId, int basicSalary, String firstName,
			String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
		// TODO Auto-generated constructor stub
	}

	public int getTotalHrs() {
		return totalHrs;
	}

	public void setTotalHrs(int totalHrs) {
		this.totalHrs = totalHrs;
	}

	public int getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}
	public void calculateTotalSalary(){
		totalHrs=50;
		
	}
}
