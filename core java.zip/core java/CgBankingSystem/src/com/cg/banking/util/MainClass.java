package com.cg.banking.util;

public class MainClass {

	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connected");
		else
			System.out.println("Not Connected");
	}
	
}
