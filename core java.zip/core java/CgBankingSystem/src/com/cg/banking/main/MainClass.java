package com.cg.banking.main;
import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		try{
		BankingServices bs = new BankingServicesImpl();
		long accountNo1=bs.openAccount("Savings", 1000);
		long accountNo2 =bs.openAccount("Salary", 1000);
		System.out.println(accountNo1+" "+accountNo2);
		Account account1 =bs.getAccountDetails(accountNo1);
		int pinNumber = account1.getPinNumber();
		System.out.println(bs.getAccountDetails(accountNo1));
		System.out.println(bs.getAccountDetails(accountNo2));
		System.out.println(bs.withdrawAmount(accountNo1, 5000, pinNumber));

		} catch(InsufficientAmountException e){
			System.out.println("Error Occured: ");
		} catch(InvalidPinNumberException e){
			System.out.println("Error Occured: "+e);
		} catch(InvalidAccountTypeException e){
			System.out.println("Error Occured: "+e);
		} catch(InvalidAmountException e){
			System.out.println("Error Occured: "+e);
		} catch(AccountBlockedException e){
			System.out.println("Error Occured: "+e);
		} catch(BankingServicesDownException e){
			System.out.println("Error Occured: "+e);
		} catch(AccountNotFoundException e){
			System.out.println("Error Occured: "+e);
		}  
	}
}
