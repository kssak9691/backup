package com.cg.banking.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.util.ConnectionProvider;

public class AccountDAOImpl implements AccountDAO{
	private Connection conn= ConnectionProvider.getDBConnection();
	@Override
	public Account save(Account account) throws SQLException{
		try{
			conn.setAutoCommit(false);
			PreparedStatement pst1 = conn.prepareStatement("INSERT INTO Account(accountType,accountBalance,status) values(?,?,?)");
			pst1.setString(1, account.getAccountType());
			pst1.setFloat(2, account.getAccountBalance());
			pst1.setString(3,"Active");
			pst1.executeUpdate();
			PreparedStatement pst2 = conn.prepareStatement("select max(accountNo) from Account");
			ResultSet rs = pst2.executeQuery();
			rs.next();
			long accountNo = rs.getInt(1);
			account.setAccountNo(accountNo);
			conn.commit();
			return account;
		} catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			throw e;
		} finally{
			conn.setAutoCommit(true);
		}	
	}
	@Override
	public Account findOne(long accountNo) throws SQLException {
		PreparedStatement pst = conn.prepareStatement("select * from account where accountNo="+accountNo);
		ResultSet rs = pst.executeQuery();
		if(rs.next()){
			Account account =new Account(rs.getInt("pinNumber"), rs.getString("AccountType"), rs.getString("status"), rs.getFloat("accountBalance"), rs.getLong("accountNo"));
			return account;
		}
		return null;
	}
	@Override
	public ArrayList<Account> findAll() throws SQLException {
		PreparedStatement pst = conn.prepareStatement("SELECT * FROM Account");
		ResultSet rs = pst.executeQuery();
		ArrayList<Account> accounts = new ArrayList<>();
		while(rs.next()){
			Account account =new Account(rs.getInt("pinNumber"), rs.getString("AccountType"), rs.getString("status"), rs.getFloat("accountBalance"), rs.getLong("accountNo"));
			accounts.add(account);
		}
		return accounts;
	}
	@Override
	public float updateTransaction(long accountNo, float amount) throws SQLException,AccountBlockedException,AccountNotFoundException{
		Account account = findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account Not Found");
		System.out.println(account);
		if(account.getStatus().compareTo("Active")==0){
			float newBalance=account.getAccountBalance()+amount;
			PreparedStatement pst1 = conn.prepareStatement("update Account set accountBalance=? where accountNo="+accountNo);
			pst1.setFloat(1, newBalance);
			pst1.executeUpdate();
			PreparedStatement pst2 = conn.prepareStatement("insert into Transaction(amount,transactionType,accountNo) values(?,?,?)");
			pst2.setFloat(1,amount);
			pst2.setString(2,"Credit");
			pst2.setLong(3,accountNo);
			pst2.executeUpdate();
			return newBalance;
		}
		else
			throw new AccountBlockedException("Your account is blocked");
	}
	@Override
	public float updateTransaction(long accountNo, float amount, int pinNumber) throws SQLException,InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		conn.setAutoCommit(false);
		Account account = findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account Not Found");
		else if(account.getStatus().compareTo("Active")!=0)
			throw new AccountBlockedException("Your Account is Blocked");
		else if(account.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("Please enter correct pin");
		else if(account.getAccountBalance()-amount<0)
			throw new InsufficientAmountException("Insufficient Balance");
		else{
			float newBalance=account.getAccountBalance()-amount;
			PreparedStatement pst1 = conn.prepareStatement("update Account set accountBalance=? where accountNo="+accountNo);
			pst1.setFloat(1, newBalance);
			pst1.executeUpdate();
			PreparedStatement pst2 = conn.prepareStatement("insert into Transaction(amount,transactionType,accountNo) values(?,?,?)");
			pst2.setFloat(1,amount);
			pst2.setString(2,"Debit");
			pst2.setLong(3,accountNo);
			pst2.executeUpdate();
			return newBalance;
		}
	}
	@Override
	public boolean updateTransaction(long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber) throws SQLException,InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException{
		updateTransaction(accountNoFrom, transferAmount, pinNumber);
		updateTransaction(accountNoTo, transferAmount);
		return true;
	}
	@Override
	public ArrayList<Transaction> findAllTransactions(long accountNo)
			throws SQLException {
		PreparedStatement pst = conn.prepareStatement("SELECT * FROM Transaction where accountNo="+accountNo);
		ResultSet rs = pst.executeQuery();
		ArrayList<Transaction> transactions = new ArrayList<>();
		while(rs.next()){
			Transaction transaction =new Transaction(rs.getInt("transactionId"), rs.getFloat("amount"), rs.getString("transactionType"),rs.getLong("accountNo"));
			transactions.add(transaction);
		}
		return transactions;
	}
	@Override
	public String findStatus(long accountNo) throws SQLException, AccountNotFoundException{
		Account account=findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException("Account Not Found");
		return account.getStatus();
	}
	
}
