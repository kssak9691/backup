package com.cg.banking.daoservices;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface AccountDAO {
	Account save(Account account) throws SQLException;
	Account findOne(long account) throws SQLException;
	ArrayList<Account> findAll() throws SQLException;
	float updateTransaction(long accountNo,float amount)throws SQLException,AccountBlockedException,AccountNotFoundException;
	float updateTransaction(long accountNo,float amount,int pinNumber)throws SQLException,InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException;
	boolean updateTransaction(long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber)throws SQLException,InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException;
	ArrayList<Transaction> findAllTransactions(long accountNo) throws SQLException;
	String findStatus(long accountNo)throws SQLException,AccountNotFoundException;
}