package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class BankingServicesTest {

	@Test
	public void test() {
		
	}

}
