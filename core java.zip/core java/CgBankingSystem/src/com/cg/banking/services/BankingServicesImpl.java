package com.cg.banking.services;
import java.sql.SQLException;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {
	AccountDAO accountDAO = new AccountDAOImpl();
	@Override
	public long openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		try{
			if(initBalance<0)
				throw new InvalidAmountException("Please enter amount correctly");
			else if(accountType.compareTo("Savings")!=0 && accountType.compareTo("Salary")!=0)
				throw new InvalidAccountTypeException("Please enter valid account type");
			Account account = new Account(accountType, initBalance);
			account=accountDAO.save(account);
			return account.getAccountNo();
		} catch(SQLException e){
			e.printStackTrace();
			BankingServicesDownException bd= new BankingServicesDownException("Services down, Sorry!!");
			throw bd;
		} 
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		try{
			if(amount<0)
				throw new InvalidAmountException("Please enter amount correctly");
		float balance = accountDAO.updateTransaction(accountNo, amount);
		return balance;
		} catch(SQLException e){
			throw new BankingServicesDownException("Services down");
		}
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
			AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		try{
			float balance = accountDAO.updateTransaction(accountNo, amount, pinNumber);
			return balance;
			} catch(SQLException e){
				throw new BankingServicesDownException("Services down");
			}
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		
		try{
			return accountDAO.updateTransaction(accountNoTo, accountNoFrom, transferAmount, pinNumber);
			} catch(SQLException e){
				throw new BankingServicesDownException("Services down");
			}
	}

	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		
		try{
			return accountDAO.findOne(accountNo);
		} catch(SQLException e){
			throw new BankingServicesDownException("Services down");
		}
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		try{
		return accountDAO.findAll();
		} catch(SQLException e){
			throw new BankingServicesDownException("Services down");
		}
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		try{
			return accountDAO.findAllTransactions(accountNo);
			} catch(SQLException e){
				throw new BankingServicesDownException("Services down");
			}
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		try{
		return accountDAO.findStatus(accountNo);
		}  catch(SQLException e){
			throw new BankingServicesDownException("Services down");
		}
	}

}
