package com.cg.payroll.dao;
import com.cg.payroll.beans.Associate;

import java.sql.SQLException;
import java.util.*;
public interface AssociateDAO {
	Associate save(Associate associate) throws SQLException;
	Associate findOne(int associateId) throws SQLException;
	ArrayList<Associate> findAll() throws SQLException;
	public boolean update(int associateId, int hra, int conveyenceAllowance,
			int otherAllowance, int personalAllowance, int gratuity,
			int grossSalary, int monthlyTax, int netSalary) throws SQLException;
}
