package com.cg.project.client;
import com.cg.project.exception.InvalidNoRangeException;
import com.cg.project.mathservices.*;
public class MainClass {	
	public static void main(String[] args) {
		try{
			MathServices services = new MathServicesImpl();
			services.mulNumbers(50, 30);
			services.addNumbers(50, -20);
		}
		catch(InvalidNoRangeException e){
			e.printStackTrace();
		}
	}
}
