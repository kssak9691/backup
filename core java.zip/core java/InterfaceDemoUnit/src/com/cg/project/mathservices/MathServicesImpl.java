package com.cg.project.mathservices;

import com.cg.project.exception.InvalidNoRangeException;

public class MathServicesImpl implements MathServices {

	@Override
	public int addNumbers(int n1, int n2) throws InvalidNoRangeException {
		if(n1<0 || n2<0)
			throw new InvalidNoRangeException("Enter positive numbers");
		return n1+n2;
	}

	@Override
	public int mulNumbers(int n1, int n2)throws InvalidNoRangeException {
		if(n1<0 || n2<0)
			throw new InvalidNoRangeException("Enter positive numbers");
		return n1*n2;
	}

	@Override
	public int subNumbers(int n1, int n2)throws InvalidNoRangeException{
		if(n1<0 || n2<0)
			throw new InvalidNoRangeException("Enter positive numbers");
		return n1-n2;
	}
	
}
