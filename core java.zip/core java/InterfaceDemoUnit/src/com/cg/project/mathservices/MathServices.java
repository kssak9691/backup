package com.cg.project.mathservices;

import com.cg.project.exception.InvalidNoRangeException;

public interface MathServices  {
	int addNumbers(int n1, int n2) throws InvalidNoRangeException;
	int mulNumbers(int n1, int n2) throws InvalidNoRangeException;
	int subNumbers(int n1, int n2)throws InvalidNoRangeException;
}
