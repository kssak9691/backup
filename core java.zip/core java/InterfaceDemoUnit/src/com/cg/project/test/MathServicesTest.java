package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exception.InvalidNoRangeException;
import com.cg.project.mathservices.MathServices;
import com.cg.project.mathservices.MathServicesImpl;

public class MathServicesTest {
	private static MathServices mathservices;
	@BeforeClass
	public static void setUPTestEnvy(){
		mathservices = new MathServicesImpl();
	}
	@Before
	public void setUPMockDataForTest(){
		
	}
	@Test(expected =InvalidNoRangeException.class)
	public void testAddNumbersFirstNoInvalid() throws InvalidNoRangeException {
		mathservices.addNumbers(-10, 20);
	}

	@Test(expected =InvalidNoRangeException.class)
	public void testAddNumbersSecondNoInvalid() throws InvalidNoRangeException {
		mathservices.addNumbers(-10, 20);
	}
	@Test
	public void testAddNumbersBothValid() throws InvalidNoRangeException {
		int expectedAns = 30;
		int result = mathservices.addNumbers(10, 20);
		assertEquals(expectedAns, result);
	}
	
	
}
