import java.io.*;
public class IOClassesDemo {
	public static void fileClassDemo() throws IOException{
		File file = new File("D:\\DataFile.txt");
		System.out.println(file.exists());
		if(!file.exists())
			file.createNewFile();
		System.out.println(file.exists());
		System.out.println(file.canRead());
		System.out.println(file.canWrite());
		System.out.println(file.length());
		System.out.println(file.getName());
		System.out.println(file.getPath());
	}
	
	public static void byteStreamReadWrite(File fileFrom,File fileTo ) throws IOException{
		try(BufferedInputStream srcStream = new BufferedInputStream(new FileInputStream(fileFrom))){
			try(BufferedOutputStream destStream = new BufferedOutputStream(new FileOutputStream(fileTo))){
				byte [] dataBuffer = new byte[(int)fileFrom.length()];
				srcStream.read(dataBuffer);
				destStream.write(dataBuffer);
			}
		}
		System.out.println("File Transfered");
	}
}
