public class Problem1 {
	public static void main(String[] args) {
		int[] A = {13,2,5,6,1};
		 if(solution(A))
			 System.out.println("array can be sorted in one operation or already sorted");
		 else
			 System.out.println("array cannot be sorted in single swap operation");			
	}
	public static boolean solution(int[ ] A){
		if(checkSorted(A))
			return true;
		for(int i=0;i<A.length-1;i++){
			for(int j=i;j<A.length-1;j++){
				swap(i,j+1,A);
				if(checkSorted(A))
					return true;
				else
					swap(i,j+1,A);
			}
		}
		return false;				
	}
	public static void swap(int a ,int b,int[] A){
		A[a]=A[a]+A[b];
		A[b]=A[a]-A[b];
		A[a]=A[a]-A[b];
	}
	public static boolean checkSorted(int[ ] A){
		int i;
	    for(i = 0; i < A.length-1; i ++){
	        if (A[i] > A[i+1])
	        	return false;
	    }
	    return true;
	}
}
