public class Problem2 {
	public static void main(String[] args) {
		int[] A={1,4,-1,3,6};
		System.out.println(solution(A));
	}
	public static int solution(int[] A){
		int j=0,count=1;
		while(A[j]!=-1 && A[j]<A.length){
				count++;
				j=A[j];
		}
		return count;
	}
}
