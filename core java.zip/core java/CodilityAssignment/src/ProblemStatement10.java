public class ProblemStatement10 {

	public static void main(String[] args) {
		int[] A={60,80,40};
		int[] B={2,3,5};
		int M=5, X=2, Y=200;
		System.out.println(solution(A,B,  M,  X, Y ));
	}
	public static int solution(int[] A, int[] B, int M, int X, int Y){
		int top=A.length-1,weight=0,count=0, flag=0,rear=0;
		while(rear<=top){
			for(int i=0;i<X;i++){
				if(rear<=top)
				weight=weight+A[rear];
				if(weight<Y && rear<=top){
					if(rear==0 || B[rear]!=B[rear-1] || flag==0)
						count=count+1;
					if (top >= rear){
						rear++;   
					}
					flag=1;
				}
				flag=0;
				weight=0;
			}
			count+=1;
		}
		return count;
	}
}
