
public class IntList {
	public int value;
	  public  IntList next;
	public IntList() {
		super();
	}
	public IntList(int value) {
		super();
		this.value = value;
	}
	  
}
