public class LengthOfLinkedList {
	static IntList first = new IntList();
	public static void main(String[] args) {
		
		for(int i=0;i<5;i++){
            insert(i+5);
        }
		System.out.println("Length of the  list is "+solution());
	}
	public static int solution(){
		int length=0;
		IntList temp = first; 
		while(temp.next!=null){
			length++;
			temp=temp.next;
		}
		return length;
	}
	public static void insert(int data) {
        IntList link = new IntList(data);
        link.next = first;
        first = link;
    }
	
}
