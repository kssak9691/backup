
public class ProblemStatement1 {

	public static void main(String[] args) {
		int[] A={0,1,3,-2,0,1,0,-3,2,3};
		int x;
		x=solution(A);
		if(x==-1)
			System.out.println("No pits in array");
		else
			System.out.println("The length of deepest pit in array is "+x);
	}
	public static int solution(int[] A){
		int depth=0,nextDepth;
		for(int p=0;p<A.length-2;p++){
			for(int q=p+1;q<A.length-1;q++){
				if(checkDecreasing(p,q,A)){
					for(int r=q+1;r<A.length;r++){
						if(checkIncreasing(q,r,A)){
							nextDepth=findDepth(p,q,r,A);
							if(nextDepth>depth)
								depth=nextDepth;
						}
					}
				}
			}
		}
		return depth;
	}
	public static boolean checkDecreasing(int a,int b,int[] A){
		for(int i=a;i<b;i++){
			if(A[i]<=A[i+1])
				return false;
		}
		return true;
	}
	public static boolean checkIncreasing(int a,int b,int[] A){
		for(int i=a;i<b;i++){
			if(A[i]>=A[i+1])
				return false;
		}
		return true;
	}
	public static int findDepth(int a,int b,int c,int[] A){
		if(A[a]-A[b]>A[c]-A[b])
			return A[c]-A[b];
		else
			return A[a]-A[b];
	}
	
}
