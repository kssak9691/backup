package com.cg.project.enumdemo;

public enum Month {
	JAN(1,"Jan"),
	FEB(2,"Feb"),
	MAR(3,"Mar"),
	APR(4,"Apr"),
	MAY(5,"May"),
	JUN(6,"Jun"),
	JUL(7,"Jul"),
	AUG(8,"Aug"),
	SEP(9,"Sep"),
	OCT(10,"Oct"),
	NOV(11,"Nov"),
	DEC(12,"Dec");
	private int monthIndex;
	private String month;

	private Month() {}
	private Month(int monthIndex, String month) {
	this.monthIndex = monthIndex;
	this.month = month;
	}
	public int getMonthIndex() {
		return monthIndex;
	}
	public void setMonthIndex(int monthIndex) {
		this.monthIndex = monthIndex;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	
}

