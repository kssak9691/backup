import java.util.Scanner;
import java.lang.String;
public class UserNameValidation {
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) {
		String string;
		System.out.println("Enter String");
		string=s.nextLine();
		if(stringValidate(string))
			System.out.println("Validation successful");
		else
			System.out.println("Validation failed");
	}
	public static boolean stringValidate(String string){
		int len = string.length();
		String str="";
		if(len<12)
			return false;
		for(int i=len-4;i<len;i++)
			str=str+string.charAt(i);
		if(str.compareTo("_job")==0)
			return true;
		return false;
	}
}
