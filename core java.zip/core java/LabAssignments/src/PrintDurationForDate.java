import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class PrintDurationForDate {
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("Enter the Date in format dd/MM/yyyy");
		String date = s.next();
		Date date1 = new Date();
		long diff;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		try {
		  Date date2 = dateFormat.parse(date);
		  if(date1.after(date2))
			  diff = date1.getTime() - date2.getTime();
		  else
			  diff = date2.getTime() - date1.getTime();
		  System.out.println("Difference between  " + dateFormat.format(date1) + " and "+ dateFormat.format(date2)+" is "
			        + (diff / (1000 * 60 * 60 * 24)) + " days, "+ ((diff/30) / (1000 * 60 * 60 * 24)) + " months, "+ ((diff/(12*30)) / (1000 * 60 * 60 * 24)) + " years.");
		} catch (ParseException e) {
		    e.printStackTrace();
		}
	}
}
