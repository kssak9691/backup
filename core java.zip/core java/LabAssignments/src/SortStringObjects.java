import java.util.Scanner;
import java.util.Arrays;
public class SortStringObjects {
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) {
		int mid;
		System.out.println("Enter the number of strings to enter");
		int len=s.nextInt();
		String[] string = new String[len];
		System.out.println("Enter the strings");
		for(int i=0;i<len;i++)
			string[i]= s.nextLine();
		for(int i=0;i<len;i++)
			string[i]=string[i].toLowerCase();
		Arrays.sort(string);
		if(len%2==0)
			mid=len/2;
		else
			mid=len/2+1;
		for(int i=0;i<len;i++){
			if(i<mid)
				string[i]=string[i].toUpperCase();
			else
				string[i]=string[i].toLowerCase();
		}
		for(int i=0;i<len;i++)
			System.out.println(string[i]);
	}
}
