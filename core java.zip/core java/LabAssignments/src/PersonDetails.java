
public class PersonDetails {

	public static void main(String[] args) {
		System.out.println("PersonDetails\n__________\n\nFirst Name: Divya\nLast Name: Bharathi"
				+ "\nGender: F\nAge: 20\nWeight: 85.55");

	}

}
