import java.util.*;
public class CheckPositiveOrNegative {
	static Scanner s = new Scanner(System.in);
	public static void main(String[] args) { 	
	int number;
	number=s.nextInt();
	if(number>0)
		System.out.println("Positive number");
	else if(number<0)
		System.out.println("Negative number");
	else
		System.out.println("Neither positive nor negative");
	}

}
