import java.util.Scanner;

public class PositiveStringCheck {
	static Scanner s= new Scanner(System.in);
	public static void main(String[] args) {
		String string;
		System.out.println("Enter String");
		string = s.nextLine(); 
		if(stringCheck(string))
			System.out.println("Positive String");
		else
			System.out.println("Negative String");
	}
	public static boolean stringCheck(String string){
		for(int i=0;i<string.length()-1;i++){
			if(string.charAt(i)>string.charAt(i+1))
				return false;
		}
		return true;
	}
}
