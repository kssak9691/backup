package com.cg.eis.pl;

import com.cg.eis.exception.SalaryException;

public interface UserServices {
	void acceptEmployeeDetails(int id, int salary,String name, String designation) throws SalaryException;
	void findInsuranceScheme();
	void employeeDetails();
}
