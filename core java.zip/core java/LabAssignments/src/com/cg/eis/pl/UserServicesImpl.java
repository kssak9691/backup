package com.cg.eis.pl;

import com.cg.eis.exception.SalaryException;
import com.cg.eis.service.EmployeeServices;
import com.cg.eis.service.EmployeeServicesImpl;

public class UserServicesImpl implements UserServices {

	private EmployeeServices service= new EmployeeServicesImpl();
	
	@Override
	public void acceptEmployeeDetails(int id, int salary, String name,
			String designation) throws SalaryException{
		service.createEmployee(id, salary, name, designation);
	}

	@Override
	public void findInsuranceScheme() {
		 service.calculateScheme();
	}

	@Override
	public void employeeDetails() {
		System.out.println(service.findDetails());

	}
	
		
	
}
