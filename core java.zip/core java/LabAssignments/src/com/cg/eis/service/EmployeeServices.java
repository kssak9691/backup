package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.SalaryException;

public interface EmployeeServices {
	void calculateScheme();
	void createEmployee(int id, int salary,String name, String designation)  throws SalaryException;
	Employee findDetails();
}
