package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.SalaryException;

public class EmployeeServicesImpl implements EmployeeServices {
	static Employee employee = new Employee();
		
	@Override
	public void createEmployee(int id, int salary,String name, String designation) throws SalaryException {
		employee = new Employee(id, salary, name, designation); 	
	}

	@Override
	public void calculateScheme() {
		int salary = employee.getSalary();
		String designation = employee.getDesignation();
		if(salary>5000 && salary<20000 && (designation.compareTo("System Associate")==0))
			employee.setInsuranceScheme("Scheme C");
		else if(salary>=20000 && salary<40000 && (designation.compareTo("Programmer")==0))
			employee.setInsuranceScheme("Scheme B");
		else if(salary>=40000 &&  (designation.compareTo("Manager")==0))
			employee.setInsuranceScheme("Scheme A");
		else if(salary<5000 &&  (designation.compareTo("Clerk")==0))
			employee.setInsuranceScheme("No Scheme");
		else
			employee.setInsuranceScheme("Not eligible");	
	}

	@Override
	public Employee findDetails() {
		return employee;
	}
	
}
