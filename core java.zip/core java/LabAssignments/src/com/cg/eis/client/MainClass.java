package com.cg.eis.client;

import java.util.Scanner;

import com.cg.eis.exception.SalaryException;
import com.cg.eis.pl.UserServices;
import com.cg.eis.pl.UserServicesImpl;

public class MainClass {
	static Scanner s= new Scanner(System.in); 
	public static void main(String[] args) {
		try{
		System.out.println("Enter EmployeeId");
		int employeeId = s.nextInt();
		System.out.println("Enter salary");
		int salary = s.nextInt();
		System.out.println("Enter name");
		String name = s.next();
		System.out.println("Enter designation");
		String designation = s.next();
		UserServices employee1 = new UserServicesImpl();
		employee1.acceptEmployeeDetails(employeeId,salary,name,designation);
		employee1.findInsuranceScheme();
		employee1.employeeDetails();
		} catch(SalaryException e){
			System.out.println("Exception Occured: "+e);
		}
	}

}
