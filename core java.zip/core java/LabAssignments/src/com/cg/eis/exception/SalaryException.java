package com.cg.eis.exception;

public class SalaryException extends Exception{
	private static final long serialVersionUID = 1L;
	private String str;
	public SalaryException(String s){
		super(s);
		str=s;
	}
	@Override
	public String toString() {
		return "SalaryException [" + str + "]";
	}	
}
