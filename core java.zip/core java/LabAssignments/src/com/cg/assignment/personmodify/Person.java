package com.cg.assignment.personmodify;

public class Person {
	private String firstName,lastName;
	private Gender gender;
	private int phoneNumber;
	public Person(String firstName, String lastName, Gender gender,
			int phoneNumber) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
	}

	public Person() {
		super();
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void displayDetails(Person person){
		System.out.println("PersonDetails\n__________\n\nFirst Name: "+this.getFirstName()+"\nLast Name: "+this.getLastName()
				+ "\nGender: "+this.getGender()+"\nphoneNumber: "+this.getPhoneNumber());
	}
	
}
