package com.cg.assignment.personmodify;

public enum Gender { 
	M,F;
}
