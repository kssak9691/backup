package com.cg.assignment.personmodify;

public class MainClass {

	public static void main(String[] args) {
		Person person = new Person("Shravan", "Marutha", Gender.M, 665485);
		person.displayDetails(person);
	}

}
