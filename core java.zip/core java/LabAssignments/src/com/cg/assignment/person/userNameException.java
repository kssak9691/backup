package com.cg.assignment.person;

public class userNameException extends Exception{
	private static final long serialVersionUID = 1L;
	private String str;
	public userNameException(String s){
		super(s);
		str=s;
	}
	@Override
	public String toString() {
		return "userNameException [" + str + "]";
	}

}
