package com.cg.assignment.person;

public class Person {
	private String firstName,lastName;
	private char gender;
	public Person() {
		super();
	}
	public Person(String firstName, String lastName, char gender) throws userNameException{
		super();

		if(firstName.compareTo("")==0  || lastName.compareTo("")==0)
			throw new userNameException("Please enter Full Name");
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;

	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
}
