package com.cg.assignment.person;

public class MainClass{

	public static void main(String[] args) {
		try{
		Person person = new Person("Shravan","", 'M') ;
		System.out.println("PersonDetails\n__________\n\nFirst Name: "+person.getFirstName()+"\nLast Name: "+person.getLastName()
				+ "\nGender: "+person.getGender());
		} catch(userNameException e){
			System.out.println("Exception Occured: "+e);
		} catch(NullPointerException e){
			System.out.println("Name Cannot be null");
		}
		
	}
	
}
