package com.cg.assignment.account;

public class Person {
	String name;
	int age;
	public Person() {
		super();
	}
	public Person(String name, int age) throws AgeException{
		super();
		if(age<15) throw new AgeException("Age should not be less than 15");
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
