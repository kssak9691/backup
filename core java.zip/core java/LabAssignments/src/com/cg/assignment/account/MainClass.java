package com.cg.assignment.account;

public class MainClass {

	public static void main(String[] args) {
		try{
		Account smith = new SavingsAccount( 2000, new Person("Smith",14));
		Account kathy = new SavingsAccount( 3000, new Person("Kathy",30));
		smith.deposit(2000);
		kathy.withdraw(2000);
		System.out.println(smith.getBalance());
		System.out.println(kathy.getBalance());
		} catch(AgeException e){
			System.out.println("Exception Occured :"+e);
		}
	}

}
