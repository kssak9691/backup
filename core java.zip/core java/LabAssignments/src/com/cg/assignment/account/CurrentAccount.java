package com.cg.assignment.account;

public class CurrentAccount extends Account{
	private static int overdraftLimit=10000;

	public CurrentAccount() {
		super();
	}

	public CurrentAccount(long balance, Person accHolder) {
		super(balance, accHolder);
	}
	

	public int getOverdraftLimit() {
		return overdraftLimit;
	}

	public void setOverdraftLimit(int limit) {
		overdraftLimit = limit;
	}

	@Override
	public void withdraw(double amount) {
		if(amount>overdraftLimit)
			System.out.println("Withdraw limit is "+overdraftLimit);
		else
			setBalance((long)(getBalance()-amount));
	}
	
}
