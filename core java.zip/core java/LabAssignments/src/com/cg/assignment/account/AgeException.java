package com.cg.assignment.account;

public class AgeException extends Exception{
	private static final long serialVersionUID = 1L;
	private String str;
	public AgeException(String s){
		super(s);
		str=s;
	}
	@Override
	public String toString() {
		return "AgeException [" + str + "]";
	}
	
}
