package com.cg.assignment.account;
		
public abstract class Account {
	static long ACCOUNT_NUMBER =232137623L;
	private long accNum;
	private long balance;
	private Person accHolder;
	
	public Account() {
		super();
	}
	public Account( long balance, Person accHolder) {
		super();
		this.accNum =ACCOUNT_NUMBER;
		this.balance = balance;
		this.accHolder = accHolder;
		ACCOUNT_NUMBER+=15;
	}
	public long getAccNum() {
		return accNum;
	}

	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void deposit(double amount){
		this.setBalance((long)(this.getBalance()+amount));
	}
	public abstract void withdraw(double amount);

	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + getAccHolder() + "]";
	}
	
}
