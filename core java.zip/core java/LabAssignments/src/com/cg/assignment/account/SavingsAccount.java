package com.cg.assignment.account;

public class SavingsAccount extends Account{
	private final int minBalance=500;
	
	public SavingsAccount() {
		super();
	}

	public SavingsAccount(long balance, Person accHolder) {
		super(balance, accHolder);
	}

	@Override
	public void withdraw(double amount) {
		if(getBalance()-amount<minBalance)
			System.out.println("Cannot Withdraw due to low balance");
		else
			setBalance((long)(getBalance()-amount));
	}	

}
