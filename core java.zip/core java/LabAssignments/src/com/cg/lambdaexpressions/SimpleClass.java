package com.cg.lambdaexpressions;

public class SimpleClass{
	public  void add(int a,int b){
			       System.out.println(a+b);
			       
	}
}
