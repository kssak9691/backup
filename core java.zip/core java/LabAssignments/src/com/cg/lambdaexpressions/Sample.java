package com.cg.lambdaexpressions;

public interface Sample {
	public void test(int a,int b);
}
