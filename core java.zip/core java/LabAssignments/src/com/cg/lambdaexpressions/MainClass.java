package com.cg.lambdaexpressions;

public class MainClass {

	public static void main(String[] args) {
		Sample sample = new SimpleClass()::add;
		sample.test(20, 30);
	}

}
