import java.util.*;
public class ExceptionHandling {
	public static void main(String[] args) {
		try{
			Scanner ref = new Scanner(System.in);
			System.out.println("Enter the number");
			int n1=ref.nextInt();
			System.out.println("Enter the number ");
			int n2 = ref.nextInt();
			System.out.println(n1/n2);
		}
		catch(InputMismatchException e){
			System.out.println("Should have enter a positive number");
		}
		catch(ArithmeticException e){

			System.out.println("Number should not be zero");
		}
	}
}
