package com.cg.payroll.services;
import java.io.DataOutput;
import java.util.ArrayList;

import com.cg.payroll.beans.*;
import com.cg.payroll.dao.*;
import com.cg.payroll.exceptions.*;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDAO = new AssociateDAOImpl() ;
	

	public PayrollServicesImpl() {
		super();
	}

	public PayrollServicesImpl(AssociateDAO mockAssociateDao) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException {
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf)); 
		
		associate=associateDAO.save(associate);
		
		return associate.getAssociateID();
	}

	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		
		associate.getSalary().setHra((30*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setConveyenceAllowance((5*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setPersonalAllowance((25*associate.getSalary().getBasicSalary())/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getHra()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		
		int yearlySalary=(associate.getSalary().getGrossSalary()*12);
		if(yearlySalary<=250000){
			associate.getSalary().setMonthlyTax(0);
		}
		else if(yearlySalary>250000 && yearlySalary<=500000)
			associate.getSalary().setMonthlyTax((int)((0.5)*(yearlySalary-250000)/12));
		else if(yearlySalary>500000 && yearlySalary<=1000000){
			int yearlyTax=25000+((int)(0.2*(yearlySalary-500000)));
			associate.getSalary().setMonthlyTax(yearlyTax/12);
			}
		else if(yearlySalary>1000000){
			int yearlyTax=125000+(30*(yearlySalary-1000000))/100;
			associate.getSalary().setMonthlyTax(yearlyTax/12);
			}
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax());
		return associate.getSalary().getNetSalary();
	}

	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate = associateDAO.findOne(associateId);
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		return associate;
	}

	@Override
	public ArrayList<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {
		return associateDAO.findAll();
	}
	
}
