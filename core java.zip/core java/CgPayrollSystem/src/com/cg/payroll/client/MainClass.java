package com.cg.payroll.client;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
public class MainClass {

	public static void main(String[] args) throws AssociateDetailsNotFoundException,PayrollServicesDownException{
		PayrollServices payrollServices = new PayrollServicesImpl();
		int associateId1,associateId2;
		associateId1=payrollServices.acceptAssociateDetails("Shravan", "Marutha", "shravan@gamil.com", "Production", "Sr.Con", "EXHPM232Q", 20000, 20000, 1500, 2000, 23424475, "HDFC", "HDFC002024");
		associateId2=payrollServices.acceptAssociateDetails("Kaushal", "Abhinav", "kaushal@gamil.com", "Production", "Sr.Con", "EXHPM596Q", 15000, 17000, 1500, 2000, 12637264, "HDFC", "HDFC002024");
		payrollServices.calculateNetSalary(associateId1);
		payrollServices.calculateNetSalary(associateId2);
		System.out.println(associateId1);
		System.out.println(associateId2);
		System.out.println(payrollServices.getAssociateDetails(associateId1));
		System.out.println(payrollServices.getAllAssociatesDetails());
	}
}