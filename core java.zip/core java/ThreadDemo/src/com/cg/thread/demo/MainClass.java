package com.cg.thread.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
		/*Runnable runnableResources = ()->{ for(int i=1;i<10;i++)System.out.println("#"+i);};
		Thread th1 = new Thread(runnableResources);
		th1.start();
		*/
		ArrayList<Employee> empList = new ArrayList<>();
		empList.add(new Employee(111,2000,"Shravan"));
		empList.add(new Employee(112,7000,"Kaushal"));
		empList.add(new Employee(113,2500,"Kalyan"));
		empList.add(new Employee(114,3000,"Suprathik"));
		empList.add(new Employee(113,2500,"Kalyan"));
		/*Collections.sort(empList, (emp1,emp2)->emp1.getSalary()-emp2.getSalary());
		
		System.out.println(empList);
		*/empList.stream();
		empList.stream().distinct()
		.filter(e->e.getName().startsWith("K"))
		.forEach(employee->System.out.println(employee));
		long count = empList.stream().distinct().count();
		System.out.println(count+" "+empList.size());

	}

}
