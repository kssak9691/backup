
public class MyThread extends Thread{

	public MyThread(String name) {
		super(name);
	}

	@Override
	public void run() {
		if(this.getName().equals("Even"))
			for(int i=2;i<=100;i+=2)
					System.out.println("Even thread="+i);
		else if(this.getName().equals("Odd"))
			for(int i=1;i<=100;i+=2)
					System.out.println("Odd thread="+i);
	}
		
	
}
