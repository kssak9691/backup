
public class MainClass {

	public static void main(String[] args) {
		MyThread th1 = new MyThread("Even");
		MyThread th2 = new MyThread("Odd");
		th1.start();
		th2.start();

	}

}
