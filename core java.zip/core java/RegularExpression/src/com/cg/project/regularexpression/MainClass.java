package com.cg.project.regularexpression;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class MainClass {

	public static void main(String[] args) {
		Pattern pattern = Pattern.compile("H[a-z]");
		Matcher matcher = pattern.matcher("Hello World How Are You");
		while(matcher.find())
			System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());
		method2();
	}
	private static void method2(){
		Pattern pattern = Pattern.compile("\\s");
		Matcher matcher = pattern.matcher("Hello World How Are You");
		while(matcher.find())
			System.out.println(matcher.start()+" "+matcher.end()+" "+matcher.group());

	}

}
