package com.zensar.project.lambdainterface;

public class MainClass {

	public static void main(String[] args) {
		FunctionalInterface1 ref1 = () -> System.out.println("**** World");
		ref1.greetUser();
		FunctionalInterface2 ref2 = (a,b) -> a+b;
		
		System.out.println(ref2.add(20, 30));
	}

}
