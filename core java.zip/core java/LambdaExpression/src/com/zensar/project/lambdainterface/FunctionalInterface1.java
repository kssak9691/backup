package com.zensar.project.lambdainterface;

@FunctionalInterface
public interface FunctionalInterface1 {
	void greetUser();
}
