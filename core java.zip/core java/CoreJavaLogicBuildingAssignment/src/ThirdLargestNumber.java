import java.util.Arrays;
public class ThirdLargestNumber {
	public static void main(String[] args) {
		int array[]={22,33,5,7,32,7,50,10};
		Arrays.sort(array);
		int n=array.length;
		System.out.println("Third largest Element:"+array[n-3]);
	}
}
