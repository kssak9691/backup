public class Armstrong {
	public static void main(String[] args) {
		int num=153,check=0,length=0,temp;
		temp=num;
		while(temp>0){
			temp/=10;
			length++;
		}
		temp=num;
		while(temp>0){
			check=(int)(check+Math.pow(temp%10,length));
			temp/=10;
		}
		if(check==num)
			System.out.println("The Number "+num+" is an Armstrong number");
		else
			System.out.println("The Number "+num+" is not an Armstrong number");
	}
}
