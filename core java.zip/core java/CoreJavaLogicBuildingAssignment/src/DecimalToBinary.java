public class DecimalToBinary {
	 public static void main(String[] args) {
	        int num = 35,remainder,temp,i=1;
	        long binaryNumber=0;
	        temp=num;
	        while(temp>0){
	        remainder = temp % 2;
	        binaryNumber +=  remainder*i;
	        i*=10;
	        temp /= 2;     
	        }
	        System.out.println(num+" in decimal is "+binaryNumber+" in binary");
	    }
}
