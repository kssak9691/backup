public class LinearArraySearch {	
	public static void main(String[] args) {	
		int linearList[]={1,2,3,4,5,6};
		int flag=0;
		for(int i=0;i<6;i++){
			
			if(linearList[i]==3){
				System.out.println("The number  is availabe at position "+(i+1));
				flag=1;
				break;
			}	
		}
		if(flag==0)
			System.out.println("The number is not available");
	}	
}
