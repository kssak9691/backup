public class ToPrintEvenAndOdd {
	public static void main(String[] args) {
		int openRange=200,closeRange=250,temp;
		temp=openRange;
		System.out.println("Even numbers in given Range are:");
		while(temp<closeRange){
			if(temp%2==0)
				System.out.println(temp);
			temp++;
		}
		temp=openRange;
		System.out.println("Odd numbers in given Range are:");
		while(temp<closeRange){
			if(temp%2==1)
				System.out.println(temp);
			temp++;
		}
	}
}
