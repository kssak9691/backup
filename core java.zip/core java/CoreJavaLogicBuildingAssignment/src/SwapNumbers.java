public class SwapNumbers {
	public static void main(String[] args) {
			int num1=30,num2=20;
			System.out.println("The numbers before swap are "+num1+" and "+num2);
			num1=num1+num2;
			num2=num1-num2;
			num1=num1-num2;
			System.out.println("The numbers after swap are "+num1+" and "+num2);
	}
}
