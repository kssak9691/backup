import java.util.Arrays;
public class MinAndMaxNumbersWithGivenNumber {
	public static void main(String[] args) {
		int num=7600309,length,temp, i,flag=0,j;
		length=(int)Math.log10(num)+1;
		int arr[] = new int[length];
		temp=num;
		for(i=0;i<length;i++){
			arr[i]=temp%10;
			temp/=10;
		}
		Arrays.sort(arr);
		temp=0;
		i=0;
		while(arr[i]==0){
			i++;
			flag=1;
		}
		if(flag==1)
			temp=arr[i];
		for(j=0;j<length;j++)
			if(j!=i)
			temp=temp*10+arr[j];
		System.out.println("The smallest number for "+num+" is "+temp);
		temp=0;
		for(j=length-1;j>=0;j--)
			temp=temp*10+arr[j];
		System.out.println("The largest number for "+num+" is "+temp);
	}
}
