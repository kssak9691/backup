public class Palindrome {
	public static void main(String[] args) {
		int num=1221,temp,check=0;
		temp=num;
		while(temp>0){
			check=check*10+temp%10;
			temp=temp/10;
		}
		if(check==num)
			System.out.println("Given number "+num+" is Palindrome");
		else
			System.out.println("Given number "+num+" is not Palindrome");
	}
}
