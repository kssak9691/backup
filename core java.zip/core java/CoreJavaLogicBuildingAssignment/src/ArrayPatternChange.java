
public class ArrayPatternChange {

	public static void main(String[] args) {
			int givenArray[]={1,2,3,4,5,6,7,8,9,10},i,j=0,k=0;
			int temp[]=new int[10];
			for(i=9;i>=5;i--){
				temp[k]=givenArray[i];
				k++;
				if(j<5){
					temp[k]=givenArray[j];
					j++;
					k++;
				}
			}
			for(i=0;i<=9;i++){
				givenArray[i]=temp[i];
			}
			for(i=0;i<=9;i++){
				System.out.println(givenArray[i]);
			}
		}


	}

