public class QuadraticRoots {

	public static void main(String[] args) 
	{
		int a=1, b=1, c=-2;
		double	 r1, r2, d;
		d = b * b - 4 * a * c;
		if(d>=0)
		{
			r1 = ( - b + Math.sqrt(d))/(2*a);
			r2 = (-b - Math.sqrt(d))/(2*a);
			System.out.println("Roots are "+r1+ " and "+r2);
		}
		else
		{
			System.out.println("Imaginary Roots");
		}
	}
}
