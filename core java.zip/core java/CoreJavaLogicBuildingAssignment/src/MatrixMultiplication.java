public class MatrixMultiplication {
	public static void main(String[] args) {
		int matrix1[][] = {
				{9,2,1}, 
				{4,2,1}, 
				{ 4,2,4}}; 

		int matrix2[][] = {
				{1,5,2}, 
				{2,2,1}, 
				{1,2,3}};
		int n=3;
		int result[][]=new int[n][n] ;
		for (int i=0; i<n; i++) { 
			for (int j=0; j<n; j++) { 
				result[i][j]=0; 
				for (int k=0; k<n; k++) 
					result[i][j] += matrix1[i][k]*matrix2[k][j]; 
			} 
		} 
		for (int i=0; i<n; i++) 
        { 
            for (int j=0; j<n; j++) 
                System.out.print( result[i][j] + " "); 
            	System.out.println(); 
        } 
	} 
}
