public class TypeOfDigitsInArray {
		public static void main(String[] args) {
			int length,count1=0,count2=0,count3=0,i;
			System.out.println("Enter the size of array :");
			int[] arr={10,3,45,435,24,134,44};
			length=arr.length;
			for (i = 0; i <length; i++) {
				if (arr[i]/10<1) {
					count1++;
				}
				if (arr[i]/10>=1 && arr[i]/10<10) {
					count2++;
				}
				if (arr[i]/10>=10 && arr[i]/10<100) {
					count3++;
				}
			}
			System.out.println("There are "+count1+" one digited numbers");
			System.out.println("There are "+count2+" two digited numbers");
			System.out.println("There are "+count3+" three digited numbers");
		}
}

