
public class BonusSalary {

	public static void main(String[] args) {
		int noOfExperience=13,bonusSalary,basicSalary;
		String designation="Sr.Con";
		if(designation=="A.Con")
			basicSalary=20000;
		else
			basicSalary=30000;
		if(noOfExperience<3)
			System.out.println("No Bonus Salary");
		else if(noOfExperience<=10 && noOfExperience>=3){
			bonusSalary=(int)(basicSalary*0.2);
			System.out.println(bonusSalary);
		}
		else if(noOfExperience>10 && noOfExperience<=20 ){
			bonusSalary=(int)(basicSalary*0.25);
			System.out.println(bonusSalary);
		}
		else if(noOfExperience>20){
			bonusSalary=(int)(basicSalary*0.3);
			System.out.println(bonusSalary);
		}
	}

}
