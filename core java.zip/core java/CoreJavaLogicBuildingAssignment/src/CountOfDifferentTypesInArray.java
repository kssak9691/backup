public class CountOfDifferentTypesInArray {
	private static int EVEN_COUNT=0, ODD_COUNT=0,PRIME_COUNT=0,PALINDROME_COUNT=0,
			ARMSTORNG_COUNT=0;
public static void main(String[] args) {
int arr[]={11,121,324,45,17,153};
for(int i=0;i<arr.length;i++){
palindrome(arr[i]);
primeNumber(arr[i]);
armstrong(arr[i]);
evenNumber(arr[i]);
oddNumber(arr[i]);
}
System.out.println("Even numbers = "+EVEN_COUNT+" Odd numbers = "+ODD_COUNT+" Prime numbers are = "
+PRIME_COUNT+" Palindrome numbers = "+PALINDROME_COUNT+" Armstrong numbers = "+ARMSTORNG_COUNT);
}
public static void palindrome(int num){
int temp,check=0;
temp=num;
while(temp>0){
check=check*10+temp%10;
temp=temp/10;
}
if(check==num)
PALINDROME_COUNT++;
}
public static void armstrong(int num){
int temp,check=0,length=0;
temp=num;
while(temp>0){
temp/=10;
length++;
}
temp=num;
while(temp>0){
check=(int)(check+Math.pow(temp%10,length));
temp/=10;
}
if(check==num)
ARMSTORNG_COUNT++;
}
public static void primeNumber(int num){ 
for(int i=2;i<num;i++){
if(num%i==0){
PRIME_COUNT++;
break;
}
}
}
public static void evenNumber(int num){ 
if(num%2==0)
EVEN_COUNT++;
}
public static void oddNumber(int num){ 
if(num%2==1)
ODD_COUNT++;
}
}
