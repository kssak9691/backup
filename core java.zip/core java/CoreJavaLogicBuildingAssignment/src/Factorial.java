
public class Factorial {
	public static void main(String[] args) {
		int num=10,result=1,i;
	   for(i=1;i<=num;i++){    
		      result=result*i;    
		  }    
		  System.out.println("Factorial is:"+result);    
		 } 
}
