public class BinaryToDecimal {
	 public static void main(String[] args) {
	        long num = 110010001,temp;
	        int decimalNumber = 0, i = 0,remainder;
	        temp=num;
	        while (temp != 0)
	        {
	            remainder =(int) temp % 10;
	            temp /= 10;
	            decimalNumber += remainder * Math.pow(2, i);
	            ++i;
	        }
	        System.out.println(num+" in binary = "+decimalNumber+" in decimal");
	    }
}
