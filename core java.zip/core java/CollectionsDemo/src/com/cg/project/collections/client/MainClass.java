package com.cg.project.collections.client;
import com.cg.project.collectionsdemo.Associate;
import com.cg.project.collections.beans.*;
public class MainClass {

	public static void main(String[] args) {
		
	}

}
