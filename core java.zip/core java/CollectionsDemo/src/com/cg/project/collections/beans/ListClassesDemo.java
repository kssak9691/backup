package com.cg.project.collections.beans;
import com.cg.project.collectionsdemo.*;
import java.util.*;
public class ListClassesDemo {
	public static void arrListClassWork(){
		ArrayList<String> strList = new ArrayList<>();
		
		strList.add("Sharvan");
		strList.add("Kaushal");
		strList.add("Satish");
		strList.add("Kaushal");
		strList.add("Abhinav");
		System.out.println(strList.contains("Satish"));
		
		Collections.sort(strList);
		for(String name:strList)
			System.out.println(name);
		
		ArrayList<Associate>associateList = new ArrayList<>();	
		associateList.add(new Associate(102,43671,"Shravan"));
		associateList.add(new Associate(103,33467,"Kaushal"));
		associateList.add(new Associate(104,41342,"Nilesh"));
		associateList.add(new Associate(105,45324,"Rakesh"));
		 
		Associate associateToBeSearch = new Associate(103,234673,"Kaushal");
		System.out.println(associateList.indexOf(associateToBeSearch));
		System.out.println(associateList.contains(associateToBeSearch));
		
		for(Associate associate: associateList){
			System.out.println(associate.getAssociateId());
		}
	}
	
	
}
