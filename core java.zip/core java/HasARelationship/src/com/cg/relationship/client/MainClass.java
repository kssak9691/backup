package com.cg.relationship.client;
import com.cg.relationship.beans.*;
public class MainClass {

	public static void main(String[] args) {
		Address address = new Address("Pune", "Maharastra", "India", 431107);
		Customer customer =new Customer(1001, "Shravan", "Marutha", address);
		System.out.println(customer.getFirstName()+" from "+customer.getAddress().getCity()); 
		customer.setAddress(new Address("Banglore", "Maharastra", "India", 431107));
		System.out.println(customer.getFirstName()+ " from "+customer.getAddress().getCity());
	}

}
