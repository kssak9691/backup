package com.cg.billing.beans;

public class Plan {
	private int planID, monthlyRental, freeLocalCalls, freeStdCalls, freeLocalSMS, freeStdSMS;
	private String freeInternetDataUsageUnits, localCallRate, stdCallRate, localSMSRate, stdSMSRate, internetDateUsageRate, planCircle, planName;
}
