package com.cg.billing.beans;

public class Address {
	private String city, state, country ;
	private int pincode;
}
