package com.cg.billing.beans;

public class PostPaidAccount {
	private int mobileNo, planId, customerId;
}
