package com.cg.billing.beans;

public class Bill {
	private int billId, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits,
	internetDataUsageUnitsAmount, stateGST, centralGST, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount;
	private String billMonth; 
}
