package com.cg.billing.beans;

public class BillingCustomer {
	private int Customerid,mobileNo, adharNo;
	private String firstName, lastName, emailID, dateOfBirth, pancard;
}
